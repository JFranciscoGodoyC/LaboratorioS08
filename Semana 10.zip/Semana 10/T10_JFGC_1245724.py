#Actividad03
print("José Francisco Godoy Castellanos- 1245724")
print("Ingrese la fecha de su nacimiento dd/mm/aaaa")
day =int(input("Ingrese el día:  "))
month = int(input("Ingrese el mes:  "))
year =int(input("Ingrese el año:  "))
if day<0 or month>12 or month<1 or year>2024:
    print("Error: Ingreso una fecha incorrecta")
match(month):
        case 1:
            if day>=20:
                print("Tu signo es zoodiacal es Acuario")
            else:
                print("Tu signo es zoodiacal es Capricornio")
        case 2:
            if day>=19:
                print("Tu signo es zoodiacal es Piscis")
            else:
                print("Tu signo es zoodiacal es Acuario")
        case 3:
            if day>=21:
                print("Tu signo es zoodiacal es Aries")
            else:
                print("Tu signo es zoodiacal es Piscis")
        case 4:
            if day>=20:
                print("Tu signo es zoodiacal es Tauro")
            else:
                print("Tu signo es zoodiacal es Aries")
        case 5:
            if day>=21:
                print("Tu signo es zoodiacal es Géminis")
            else:
                print("Tu signo es zoodiacal es Tauro")
        case 6:
            if day>=21:
                print("Tu signo es zoodiacal es Cancer")
            else:
                print("Tu signo es zoodiacal es Géminis")
        case 7:
            if day>=23:
                print("Tu signo es zoodiacal es Leo")
            else:
                print("Tu signo es zoodiacal es Cancer")
        case 8:
            if day>=23:
                print("Tu signo es zoodiacal es Virgo")
            else:
                print("Tu signo es zoodiacal es Leo")    
        case 9:
            if day>=23:
                print("Tu signo es zoodiacal es Libra")
            else:
                print("Tu signo es zoodiacal es Virgo")
        case 10:
            if day>=23:
                print("Tu signo es zoodiacal es Escorpio")
            else:
                print("Tu signo es zoodiacal es Libra")
        case 11:
            if day>=22:
                print("Tu signo es zoodiacal es Sagitario")
            else:
                print("Tu signo es zoodiacal es Escorpio")
        case 12:
            if day>=22:
                print("Tu signo es zoodiacal es Capricornio")
            else:
                print("Tu signo es zoodiacal es Sagitario")
