#Francisco Godoy 1245724
#Ejercicio 01
print("Semana No. 10: Ejercicio 1")
mes=int(input("Ingrese un número entre 1 y 12: "))
if mes<1 or mes >12:
    print("Error: el número debe estar entre 1 y 12")
else: 
    #Validando
    if mes==1:
        print("Mes: Enero")
    elif mes==2:
        print==("Mes: Febrero")
    elif mes==3:
        print("Mes: Marzo")
    elif mes==4:
        print("Mes: Abril")
    elif mes==5:
        print("Mes: Mayo")
    elif mes==6:
        print("Mes: Junio")
    elif mes==7:
        print("Mes: Julio")
    elif mes==8:
        print("Mes: Agosto")
    elif mes==9:
        print("Mes: Septiembre")
    elif mes==10:
        print("Mes: Octubre")
    elif mes==11:
        print("Mes: Noviembre")
    else:
        print("Mes: Diciembre")

    #validando con case
    match(mes):
        case 1:
            print("Mes: Enero")
        case 2:
            print("Mes: Febrero")
        case 3:
            print("Mes: Marzo")
        case 4:
            print("Mes: Abril")
        case 5:
            print("Mes: Mayo")
        case 6:
            print("Mes: Junio")
        case 7:
            print("Mes: Julio")
        case 8:
            print("Mes: Agosto")
        case 9:
            print("Mes: Septiembre")
        case 10:
            print("Mes: Octubre")
        case 11:
            print("Mes: Noviembre")
        case 12:
            print("Mes: Diciembre")

#Ejercicio 02
print()
print("Semana 10: Ejercicio 2")

A=int(input("Ingrese el primer numero: "))
B=int(input("Ingrese el segundo numero: "))
C=int(input("Ingrese el tercer numero: "))
if A<0 or B<0 or C<0:
    print("Error: el número debe ser mayor a 0")
else:
    if A > B:
        if A > C:
            print("El mayor es:", A)
        else:
            print("El mayor es:", C)
    elif A == B:
        if A > C:
            print("Los mayores son:", A, "y", B)
        elif A == C:
            print("Los tres valores son iguales")
        else:
            print("El mayor es:", C)
    else:
        if B > C:
            print("El mayor es:", B)
        elif B == C:
            print("Los mayores son:", B, "y", C)
        else:
            print("El mayor es:", C)